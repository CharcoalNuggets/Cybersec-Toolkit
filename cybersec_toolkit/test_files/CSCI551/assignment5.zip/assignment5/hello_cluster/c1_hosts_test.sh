#!/bin/sh
ping -c 10 -w 3 o251-01
ping -c 10 -w 3 o251-02
ping -c 10 -w 3 o251-03
ping -c 10 -w 3 o251-04
ping -c 10 -w 3 o251-05
ping -c 10 -w 3 o251-06
ping -c 10 -w 3 o251-07
ping -c 10 -w 3 o251-08
ping -c 10 -w 3 o251-09
ping -c 10 -w 3 o251-10
ping -c 10 -w 3 o251-11
ping -c 10 -w 3 o251-12
ping -c 10 -w 3 o251-13
ping -c 10 -w 3 o251-14
ping -c 10 -w 3 o251-15
ping -c 10 -w 3 o251-16
ping -c 10 -w 3 o251-17
ping -c 10 -w 3 o251-18
ping -c 10 -w 3 o251-19
ping -c 10 -w 3 o251-20
ping -c 10 -w 3 o251-21
ping -c 10 -w 3 o251-22
ping -c 10 -w 3 o251-23
ping -c 10 -w 3 o251-24
ping -c 10 -w 3 o251-25
ping -c 10 -w 3 o251-26
ping -c 10 -w 3 o251-27
ping -c 10 -w 3 o251-28
ping -c 10 -w 3 o251-29
ping -c 10 -w 3 o251-30
ping -c 10 -w 3 o251-31

sleep 3
