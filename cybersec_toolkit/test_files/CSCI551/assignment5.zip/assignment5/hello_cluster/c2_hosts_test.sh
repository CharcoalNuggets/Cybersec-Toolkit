#!/bin/sh
ping -c 10 -w 3 o244-01
ping -c 10 -w 3 o244-02
ping -c 10 -w 3 o244-03
ping -c 10 -w 3 o244-04
ping -c 10 -w 3 o244-05
ping -c 10 -w 3 o244-06
ping -c 10 -w 3 o244-07
ping -c 10 -w 3 o244-08
ping -c 10 -w 3 o244-09
ping -c 10 -w 3 o244-10
ping -c 10 -w 3 o244-11
ping -c 10 -w 3 o244-12
ping -c 10 -w 3 o244-13
ping -c 10 -w 3 o244-14
ping -c 10 -w 3 o244-15
ping -c 10 -w 3 o244-16
ping -c 10 -w 3 o244-17
ping -c 10 -w 3 o244-18
ping -c 10 -w 3 o244-19
ping -c 10 -w 3 o244-20
ping -c 10 -w 3 o244-21
ping -c 10 -w 3 o244-22
ping -c 10 -w 3 o244-23
ping -c 10 -w 3 o244-24
ping -c 10 -w 3 o244-25
ping -c 10 -w 3 o244-26
ping -c 10 -w 3 o244-27
ping -c 10 -w 3 o244-28
ping -c 10 -w 3 o244-29
ping -c 10 -w 3 o244-30
ping -c 10 -w 3 o244-31

sleep 3
