// Should match list of file names in https://www.ecst.csuchico.edu/~sbsiewert/csci551/code/cards_3x4_pgm/
//
char cardfilelist[52][8] =
{"2C.pgm", "2D.pgm", "2H.pgm", "2S.pgm", "3C.pgm", "3D.pgm", "3H.pgm", "3S.pgm",
 "4C.pgm", "4D.pgm", "4H.pgm", "4S.pgm", "5C.pgm", "5D.pgm", "5H.pgm", "5S.pgm",
 "6C.pgm", "6D.pgm", "6H.pgm", "6S.pgm", "7C.pgm", "7D.pgm", "7H.pgm", "7S.pgm",
 "8C.pgm", "8D.pgm", "8H.pgm", "8S.pgm", "9C.pgm", "9D.pgm", "9H.pgm", "9S.pgm",
 "10C.pgm", "10D.pgm", "10H.pgm", "10S.pgm", "AC.pgm", "AD.pgm", "AH.pgm", "AS.pgm",
 "JC.pgm", "JD.pgm", "JH.pgm", "JS.pgm", "KC.pgm", "KD.pgm", "KH.pgm", "KS.pgm",
 "QC.pgm", "QD.pgm", "QH.pgm", "QS.pgm"
 };


